var class_user =
[
    [ "User", "class_user.html#abf2df4cc3d4aedff7d8f2ef76c44d102", null ],
    [ "getAge", "class_user.html#a71385d4c5a3a509af5024b3c8e1e1aa9", null ],
    [ "getNick", "class_user.html#a0d92dd92076037e61fc17e6d67e35698", null ],
    [ "save", "class_user.html#a04d6f029180eca80e55d09be738cdd12", null ],
    [ "type", "class_user.html#a902b3338981f25630aff8262c13a8d92", null ],
    [ "bd", "class_user.html#acbdce7f54e8a6b8f5b583127969ff7b9", null ],
    [ "name", "class_user.html#a085d8d69282b6298964eab8351584536", null ],
    [ "nickname", "class_user.html#aebdb6953485740c33307118f91156832", null ]
];