var class_not_in_whitelist =
[
    [ "NotInWhitelist", "class_not_in_whitelist.html#adda44364b5283721788c4c74d2ae9e1f", null ]
];