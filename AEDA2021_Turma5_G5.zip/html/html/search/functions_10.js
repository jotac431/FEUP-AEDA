var searchData=
[
  ['uniquenickname_237',['uniqueNickname',['../class_stream_z.html#a73780b51815a0f0e6d40267519eed1cc',1,'StreamZ']]],
  ['user_238',['User',['../class_user.html#abf2df4cc3d4aedff7d8f2ef76c44d102',1,'User']]],
  ['userallowed_239',['userAllowed',['../class_private_stream.html#a0d0cad07903750a66fbc5c81fc59481e',1,'PrivateStream']]]
];
