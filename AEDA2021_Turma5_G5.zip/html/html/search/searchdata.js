var indexSectionsWithContent =
{
  0: "abcdefghijlmnoprstuvw",
  1: "abdnpstuv",
  2: "demsu",
  3: "acdefghijlmoprstuvw",
  4: "c",
  5: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "enums",
  5: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Enumerations",
  5: "Friends"
};

