var searchData=
[
  ['printfeedback_211',['printFeedback',['../class_stream.html#ad641e976ea37b0550e9a722964ed5642',1,'Stream::printFeedback()'],['../class_private_stream.html#a83538b0a559e782b9682ac67940ccc97',1,'PrivateStream::printFeedback()']]],
  ['printvector_212',['printVector',['../class_stream_z.html#ac57d5513d26030652f47898d89373dae',1,'StreamZ']]],
  ['privatefeedback_213',['privateFeedback',['../class_private_stream.html#a316172798bb08508a597b90f5b8d35f9',1,'PrivateStream::privateFeedback()'],['../class_viewer.html#a0472106504b871eb879105f046680972',1,'Viewer::privateFeedback()']]],
  ['privatepublic_214',['privatePublic',['../class_stream_z.html#af7473362bda002025e77031934bcd708',1,'StreamZ::privatePublic()'],['../main_8cpp.html#a7bf816d8a13255da4b0c762f558eb803',1,'privatepublic():&#160;main.cpp']]],
  ['privatestream_215',['PrivateStream',['../class_private_stream.html#ac2c2497c30daeda1114cc97dbaf8113a',1,'PrivateStream::PrivateStream(std::string t, std::string lang, int age, Streamer *st, int capacity)'],['../class_private_stream.html#a892110e77c92baac9ca544e27beae081',1,'PrivateStream::PrivateStream(std::string t, std::string lang, int age, Streamer *st, int capacity, int y, int m, int d, int l, int dl)'],['../class_private_stream.html#a7799fe6b119e75516a794d92358069fc',1,'PrivateStream::PrivateStream(std::string t, std::string lang, int age, Streamer *st, int capacity, int y, int m, int d, int l, int dl, int views)']]],
  ['publicfeedback_216',['publicFeedback',['../class_viewer.html#a94bfba0927cc69fdd65d0b5883b6bfd4',1,'Viewer']]]
];
