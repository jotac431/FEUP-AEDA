var searchData=
[
  ['getage_33',['getAge',['../class_user.html#a71385d4c5a3a509af5024b3c8e1e1aa9',1,'User']]],
  ['getdate_34',['getDate',['../class_stream.html#aad821b8d68c6f836018b5212ac9ba46f',1,'Stream']]],
  ['getlanguage_35',['getLanguage',['../class_stream.html#a6c46e41c618088340b17f84ea16e59ad',1,'Stream']]],
  ['getlikes_36',['getLikes',['../class_stream.html#a8636b345e777a18d23ba1a88f82482b8',1,'Stream']]],
  ['getnick_37',['getNick',['../class_user.html#a0d92dd92076037e61fc17e6d67e35698',1,'User']]],
  ['getstream_38',['getStream',['../class_streamer.html#a0e7c7eea5911bae678bc46ed31042da9',1,'Streamer']]],
  ['getstreamhistory_39',['getStreamHistory',['../class_streamer.html#a2cd8732293d7fb6be144d55601e658d6',1,'Streamer']]],
  ['getviewercount_40',['getViewerCount',['../class_stream.html#a886d5b91bd1a71113ce5b73d0a3905fb',1,'Stream']]],
  ['getwhitelist_41',['getWhiteList',['../class_private_stream.html#a5101b76dd51f964df222334f7e60ad74',1,'PrivateStream']]]
];
