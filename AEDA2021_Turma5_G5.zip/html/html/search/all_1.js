var searchData=
[
  ['baddate_13',['BadDate',['../class_bad_date.html',1,'']]],
  ['badfile_14',['BadFile',['../class_bad_file.html',1,'']]]
];
