var searchData=
[
  ['save_220',['save',['../class_stream.html#ad1707cca91585539c9050687d6eef5d3',1,'Stream::save()'],['../class_private_stream.html#af77aab8dfda68dd23e9522dcead02324',1,'PrivateStream::save()'],['../class_user.html#a04d6f029180eca80e55d09be738cdd12',1,'User::save()'],['../class_viewer.html#a24ac54933b77bd335998e50eef03f96f',1,'Viewer::save()'],['../class_streamer.html#a5653dbb785828198854c218ab95f8adb',1,'Streamer::save()'],['../class_admin.html#a3d8798099edfbc5652713b310d3e6d7a',1,'Admin::save()'],['../main_8cpp.html#adc9746b7d90eb05200c7af9160f8eb35',1,'save():&#160;main.cpp']]],
  ['savedata_221',['saveData',['../class_stream_z.html#affdd7217babf08b46f23ec625f9a777a',1,'StreamZ']]],
  ['search_222',['search',['../class_stream_z.html#ab4ff6488de312152e3e94b970827d275',1,'StreamZ::search(std::string language) const'],['../class_stream_z.html#ac378040ea726bdc484cee50fdf4cdc5c',1,'StreamZ::search(int age) const'],['../class_stream_z.html#a0a9dedabe03ff04cbe3656d8322de44d',1,'StreamZ::search(std::string language, int age) const'],['../main_8cpp.html#a413220c7a3e920a7f2d2f897e0ceea74',1,'search():&#160;main.cpp']]],
  ['select_223',['select',['../class_stream_z.html#ac3372c6e5a69c188e1eb7fe4b45a2499',1,'StreamZ']]],
  ['selection_224',['selection',['../main_8cpp.html#a4e4492a8a7c707176ca2e26959094c9a',1,'main.cpp']]],
  ['sequentialsearch_225',['sequentialSearch',['../utils_8h.html#a8c2fd0e3c1e98ceb41386c063d5b1587',1,'utils.h']]],
  ['setstream_226',['setStream',['../class_streamer.html#a00ba6c413efed2edd6786bae63e9b477',1,'Streamer']]],
  ['showwhitelist_227',['showWhiteList',['../class_streamer.html#a6d8de38bf992574815cac95056e91521',1,'Streamer']]],
  ['sortlikes_228',['sortLikes',['../class_stream_z.html#a9231539b4b5917929c266f490c1dfa65',1,'StreamZ']]],
  ['sortviews_229',['sortViews',['../class_stream_z.html#a65cce963ca9b85cc20ef26ad6185816c',1,'StreamZ']]],
  ['stream_230',['Stream',['../class_stream.html#a7fa614caa9180fd40b138b82f01e4055',1,'Stream::Stream(std::string t, std::string lang, int age, Streamer *st)'],['../class_stream.html#af7e710dfec3af340654b0c2ef5a492d4',1,'Stream::Stream(std::string t, std::string lang, int age, Streamer *st, int y, int m, int d, int l, int dl)'],['../class_stream.html#a909ec646022478c82925a10dbe6078f9',1,'Stream::Stream(std::string t, std::string lang, int age, Streamer *st, int y, int m, int d, int l, int dl, int views)']]],
  ['streamer_231',['Streamer',['../class_streamer.html#aaa3fcf8b35b56558d0828706b356e108',1,'Streamer']]],
  ['streamermenu_232',['streamerMenu',['../main_8cpp.html#a05996ebebfd6f2b08118665437482f7a',1,'main.cpp']]],
  ['streamername_233',['streamerName',['../class_stream.html#a3b0374f4ee78ca1238e5110190f2a697',1,'Stream']]],
  ['streaming_234',['streaming',['../class_streamer.html#ac1c6e2758bbfb8de822ed65f5266a625',1,'Streamer']]],
  ['streamquantity_235',['streamQuantity',['../class_stream_z.html#acf9245afd4703be8eacfa074d714b779',1,'StreamZ']]]
];
