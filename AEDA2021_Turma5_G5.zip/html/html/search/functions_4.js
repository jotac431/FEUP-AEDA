var searchData=
[
  ['feedback_180',['feedback',['../class_stream.html#a736a6dddd99e97b9693a4a310127a4c5',1,'Stream::feedback()'],['../main_8cpp.html#a1e815e89b361e2a2e36bc495aa2d469c',1,'feedback():&#160;main.cpp']]],
  ['filterstreams_181',['filterStreams',['../class_stream_z.html#a916337646c8b8e3b4b58cc9368e64d4d',1,'StreamZ::filterStreams(std::vector&lt; Stream * &gt; &amp;vec, std::string lang) const'],['../class_stream_z.html#ade49ef9838f177813c6755fbca543ee1',1,'StreamZ::filterStreams(std::vector&lt; Stream * &gt; &amp;vec, int age) const']]],
  ['firstupper_182',['firstUpper',['../utils_8cpp.html#a46878cc06673d019f670063d5939f3c6',1,'firstUpper(std::string st):&#160;utils.cpp'],['../utils_8h.html#a46878cc06673d019f670063d5939f3c6',1,'firstUpper(std::string st):&#160;utils.cpp']]]
];
