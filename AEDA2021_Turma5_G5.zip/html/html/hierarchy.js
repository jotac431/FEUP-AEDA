var hierarchy =
[
    [ "BadDate", "class_bad_date.html", null ],
    [ "BadFile", "class_bad_file.html", null ],
    [ "Date", "class_date.html", null ],
    [ "NickIsTaken", "class_nick_is_taken.html", null ],
    [ "NoStreamsFound", "class_no_streams_found.html", null ],
    [ "NotInWhitelist", "class_not_in_whitelist.html", null ],
    [ "PrivateStreamFull", "class_private_stream_full.html", null ],
    [ "Stream", "class_stream.html", [
      [ "PrivateStream", "class_private_stream.html", null ]
    ] ],
    [ "StreamerAlreadyStreaming", "class_streamer_already_streaming.html", null ],
    [ "StreamerNotStreaming", "class_streamer_not_streaming.html", null ],
    [ "StreamerTooYoung", "class_streamer_too_young.html", null ],
    [ "StreamNotPrivate", "class_stream_not_private.html", null ],
    [ "StreamZ", "class_stream_z.html", null ],
    [ "TooYoungForStream", "class_too_young_for_stream.html", null ],
    [ "User", "class_user.html", [
      [ "Admin", "class_admin.html", null ],
      [ "Streamer", "class_streamer.html", null ],
      [ "Viewer", "class_viewer.html", null ]
    ] ],
    [ "UserNotFound", "class_user_not_found.html", null ],
    [ "ViewerAlreadyWatching", "class_viewer_already_watching.html", null ],
    [ "ViewerNotWatching", "class_viewer_not_watching.html", null ],
    [ "ViewerTooYoung", "class_viewer_too_young.html", null ]
];