var class_streamer_too_young =
[
    [ "StreamerTooYoung", "class_streamer_too_young.html#ab4a8a60233c7616c50fc53b036f6a455", null ],
    [ "age", "class_streamer_too_young.html#aa1da927ebbbbc1af151c519d88342c86", null ]
];