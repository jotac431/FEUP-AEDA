var class_too_young_for_stream =
[
    [ "TooYoungForStream", "class_too_young_for_stream.html#a8ea1394ea53f3074b145ab2d54db1e1d", null ],
    [ "ageLimit", "class_too_young_for_stream.html#a8b32cba00c809e4c9eb42a5b2c3c6abf", null ]
];