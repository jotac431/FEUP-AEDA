var class_viewer =
[
    [ "Viewer", "class_viewer.html#a9fd61c8cb9890928dc597698c1b62072", null ],
    [ "leaveStream", "class_viewer.html#a1bcb6d912b95fe17dca5d6c0b811ffe7", null ],
    [ "privateFeedback", "class_viewer.html#a0472106504b871eb879105f046680972", null ],
    [ "publicFeedback", "class_viewer.html#a94bfba0927cc69fdd65d0b5883b6bfd4", null ],
    [ "save", "class_viewer.html#a24ac54933b77bd335998e50eef03f96f", null ],
    [ "type", "class_viewer.html#a540a73de90a0f7bfbca4be43d91843db", null ],
    [ "watching", "class_viewer.html#ad7b314efbe2fed24b6b6ba7aada7cf70", null ],
    [ "watchStream", "class_viewer.html#a60bd983264c9b7b6ae328ad23fb59456", null ],
    [ "operator<<", "class_viewer.html#a584a685197be3541694d8781e0474b62", null ]
];