var class_private_stream =
[
    [ "PrivateStream", "class_private_stream.html#ac2c2497c30daeda1114cc97dbaf8113a", null ],
    [ "PrivateStream", "class_private_stream.html#a892110e77c92baac9ca544e27beae081", null ],
    [ "PrivateStream", "class_private_stream.html#a7799fe6b119e75516a794d92358069fc", null ],
    [ "addToList", "class_private_stream.html#a7172077206c9c91b439a73ed8d13a963", null ],
    [ "getWhiteList", "class_private_stream.html#a5101b76dd51f964df222334f7e60ad74", null ],
    [ "info", "class_private_stream.html#ac25d5a7522f227fbd2830ba1e4a3c8a2", null ],
    [ "isFull", "class_private_stream.html#a3a347898db797e7a317170b43b7d42f6", null ],
    [ "isPrivate", "class_private_stream.html#aa1abdbffc045311e50766cb8ed6aeb95", null ],
    [ "printFeedback", "class_private_stream.html#a83538b0a559e782b9682ac67940ccc97", null ],
    [ "privateFeedback", "class_private_stream.html#a316172798bb08508a597b90f5b8d35f9", null ],
    [ "removeFromList", "class_private_stream.html#a4e5d5ae896158c7fb8d9af7c47228ff9", null ],
    [ "save", "class_private_stream.html#af77aab8dfda68dd23e9522dcead02324", null ],
    [ "userAllowed", "class_private_stream.html#a0d0cad07903750a66fbc5c81fc59481e", null ]
];