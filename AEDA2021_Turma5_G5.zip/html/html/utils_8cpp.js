var utils_8cpp =
[
    [ "Color", "utils_8cpp.html#a3e9b416a67a84d8ca97c4cce7e8b471e", null ],
    [ "firstUpper", "utils_8cpp.html#a46878cc06673d019f670063d5939f3c6", null ],
    [ "lowercase", "utils_8cpp.html#a0c059e7053ab8418c35efd508d797496", null ]
];