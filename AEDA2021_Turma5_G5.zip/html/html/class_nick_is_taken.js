var class_nick_is_taken =
[
    [ "NickIsTaken", "class_nick_is_taken.html#a88cebe91c5c207c545dea3ccecac85d9", null ],
    [ "getConflict", "class_nick_is_taken.html#ab8fc2c25265c4096d5fd19818bbe6a5e", null ]
];