var class_stream_not_private =
[
    [ "StreamNotPrivate", "class_stream_not_private.html#a6cadded37f6382e752dc1b4b10a97b43", null ]
];