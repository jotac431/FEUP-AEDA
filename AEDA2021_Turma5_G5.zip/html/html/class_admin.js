var class_admin =
[
    [ "Admin", "class_admin.html#a1b4274316c0d4af130dee8dca2284959", null ],
    [ "save", "class_admin.html#a3d8798099edfbc5652713b310d3e6d7a", null ],
    [ "type", "class_admin.html#ab983d185b0ca4f555d2241d5ca3f6cf5", null ],
    [ "operator<<", "class_admin.html#a0fd31dd3ec7c751547ae45cc605e310b", null ]
];