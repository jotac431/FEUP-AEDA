var utils_8h =
[
    [ "Color", "utils_8h.html#a3e9b416a67a84d8ca97c4cce7e8b471e", null ],
    [ "firstUpper", "utils_8h.html#a46878cc06673d019f670063d5939f3c6", null ],
    [ "lowercase", "utils_8h.html#a0c059e7053ab8418c35efd508d797496", null ],
    [ "sequentialSearch", "utils_8h.html#a8c2fd0e3c1e98ceb41386c063d5b1587", null ]
];